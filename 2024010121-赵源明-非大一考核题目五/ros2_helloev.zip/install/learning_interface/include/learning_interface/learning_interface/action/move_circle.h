// generated from rosidl_generator_c/resource/idl.h.em
// with input from learning_interface:action/MoveCircle.idl
// generated code does not contain a copyright notice

#ifndef LEARNING_INTERFACE__ACTION__MOVE_CIRCLE_H_
#define LEARNING_INTERFACE__ACTION__MOVE_CIRCLE_H_

#include "learning_interface/action/detail/move_circle__struct.h"
#include "learning_interface/action/detail/move_circle__functions.h"
#include "learning_interface/action/detail/move_circle__type_support.h"

#endif  // LEARNING_INTERFACE__ACTION__MOVE_CIRCLE_H_
