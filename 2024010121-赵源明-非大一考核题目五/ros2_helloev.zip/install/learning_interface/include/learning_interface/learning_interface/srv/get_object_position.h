// generated from rosidl_generator_c/resource/idl.h.em
// with input from learning_interface:srv/GetObjectPosition.idl
// generated code does not contain a copyright notice

#ifndef LEARNING_INTERFACE__SRV__GET_OBJECT_POSITION_H_
#define LEARNING_INTERFACE__SRV__GET_OBJECT_POSITION_H_

#include "learning_interface/srv/detail/get_object_position__struct.h"
#include "learning_interface/srv/detail/get_object_position__functions.h"
#include "learning_interface/srv/detail/get_object_position__type_support.h"

#endif  // LEARNING_INTERFACE__SRV__GET_OBJECT_POSITION_H_
