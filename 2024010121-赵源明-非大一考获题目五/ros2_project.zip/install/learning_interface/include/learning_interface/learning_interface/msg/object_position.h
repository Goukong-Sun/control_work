// generated from rosidl_generator_c/resource/idl.h.em
// with input from learning_interface:msg/ObjectPosition.idl
// generated code does not contain a copyright notice

#ifndef LEARNING_INTERFACE__MSG__OBJECT_POSITION_H_
#define LEARNING_INTERFACE__MSG__OBJECT_POSITION_H_

#include "learning_interface/msg/detail/object_position__struct.h"
#include "learning_interface/msg/detail/object_position__functions.h"
#include "learning_interface/msg/detail/object_position__type_support.h"

#endif  // LEARNING_INTERFACE__MSG__OBJECT_POSITION_H_
