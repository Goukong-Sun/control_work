// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LEARNING_INTERFACE__MSG__OBJECT_POSITION_HPP_
#define LEARNING_INTERFACE__MSG__OBJECT_POSITION_HPP_

#include "learning_interface/msg/detail/object_position__struct.hpp"
#include "learning_interface/msg/detail/object_position__builder.hpp"
#include "learning_interface/msg/detail/object_position__traits.hpp"
#include "learning_interface/msg/detail/object_position__type_support.hpp"

#endif  // LEARNING_INTERFACE__MSG__OBJECT_POSITION_HPP_
