// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LEARNING_INTERFACE__ACTION__MOVE_CIRCLE_HPP_
#define LEARNING_INTERFACE__ACTION__MOVE_CIRCLE_HPP_

#include "learning_interface/action/detail/move_circle__struct.hpp"
#include "learning_interface/action/detail/move_circle__builder.hpp"
#include "learning_interface/action/detail/move_circle__traits.hpp"
#include "learning_interface/action/detail/move_circle__type_support.hpp"

#endif  // LEARNING_INTERFACE__ACTION__MOVE_CIRCLE_HPP_
