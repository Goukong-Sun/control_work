// generated from rosidl_generator_c/resource/idl.h.em
// with input from learning_interface:srv/AddTwoInts.idl
// generated code does not contain a copyright notice

#ifndef LEARNING_INTERFACE__SRV__ADD_TWO_INTS_H_
#define LEARNING_INTERFACE__SRV__ADD_TWO_INTS_H_

#include "learning_interface/srv/detail/add_two_ints__struct.h"
#include "learning_interface/srv/detail/add_two_ints__functions.h"
#include "learning_interface/srv/detail/add_two_ints__type_support.h"

#endif  // LEARNING_INTERFACE__SRV__ADD_TWO_INTS_H_
