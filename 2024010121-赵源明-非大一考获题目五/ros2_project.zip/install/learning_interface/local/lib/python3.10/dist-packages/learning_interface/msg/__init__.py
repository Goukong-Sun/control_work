from learning_interface.msg._object_position import ObjectPosition  # noqa: F401
